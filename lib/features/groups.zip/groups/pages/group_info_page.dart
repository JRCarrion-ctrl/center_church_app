// File: lib/features/groups/pages/group_info_page.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../widgets/group_chat_tab.dart';

class GroupInfoPage extends StatelessWidget {
  final String groupId;
  final bool isAdmin;

  const GroupInfoPage({super.key, required this.groupId, required this.isAdmin});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Info'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildGroupHeader(context),
          const SizedBox(height: 24),
          _buildSectionHeader('Pinned Messages'),
          _buildPinnedMessages(context),
          const SizedBox(height: 24),
          _buildSectionHeader('Events'),
          _buildGroupEvents(context),
          const SizedBox(height: 24),
          _buildSectionHeader('Announcements'),
          _buildGroupAnnouncements(context),
          const SizedBox(height: 24),
          _buildSectionHeader('Media'),
          _buildGroupMedia(context),
          const SizedBox(height: 24),
          _buildSectionHeader('Members'),
          _buildGroupMembers(context),
        ],
      ),
    );
  }

  Widget _buildGroupHeader(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: isAdmin ? () => _changeGroupPhoto(context) : null,
          child: CircleAvatar(
            radius: 40,
            backgroundImage: NetworkImage('https://via.placeholder.com/150'),
          ),
        ),
        const SizedBox(height: 12),
        isAdmin ? _editableGroupName(context) : const Text('Group Name', style: TextStyle(fontSize: 20)),
        const SizedBox(height: 8),
        isAdmin ? _editableGroupDescription(context) : const Text('Group description goes here.')
      ],
    );
  }

  Widget _editableGroupName(BuildContext context) {
    return TextFormField(
      initialValue: 'Group Name',
      decoration: const InputDecoration(labelText: 'Group Name'),
      onFieldSubmitted: (value) {
        // TODO: Save to Supabase
      },
    );
  }

  Widget _editableGroupDescription(BuildContext context) {
    return TextFormField(
      initialValue: 'Group description goes here.',
      maxLines: 2,
      decoration: const InputDecoration(labelText: 'Description'),
      onFieldSubmitted: (value) {
        // TODO: Save to Supabase
      },
    );
  }

  Widget _buildSectionHeader(String title) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));

  Widget _buildPinnedMessages(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.of(context).pop();
        Future.delayed(const Duration(milliseconds: 300), () {
          GroupChatTab.scrollToPinnedMessage(context);
        });
      },
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text("\ud83d\udccc \u201cDon't forget worship practice tonight at 7pm.\u201d",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 4),
              Text("Posted by Sarah \u2022 2 days ago",
                style: TextStyle(color: Colors.grey),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGroupEvents(BuildContext context) {
    final List<Map<String, String>> upcomingEvents = [
      {'title': 'Sunday Worship', 'date': 'Jul 14'},
      {'title': 'Youth Night', 'date': 'Jul 17'},
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...upcomingEvents.map((event) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(event['title']!, style: Theme.of(context).textTheme.bodyMedium),
                  Text(event['date']!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey)),
                ],
              ),
            )),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => context.push('/groups/$groupId/events'),
                  child: const Text('View All Events'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildGroupAnnouncements(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('“Bring a friend this Sunday!”', maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            const Text('Posted by Pastor Mike • Jul 10', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => context.push('/groups/$groupId/announcements'),
                  child: const Text('View All'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildGroupMedia(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ...List.generate(3, (index) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.network(
                      'https://via.placeholder.com/80x80?text=Media${index + 1}',
                      width: 80,
                      height: 80,
                      fit: BoxFit.cover,
                    ),
                  ),
                ))
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => context.push('/groups/$groupId/media'),
                  child: const Text('View All'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _buildGroupMembers(BuildContext context) {
    final List<Map<String, String>> members = [
      {'name': 'Sarah L.', 'role': 'Leader'},
      {'name': 'Daniel K.', 'role': 'Member'},
      {'name': 'Jess T.', 'role': 'Member'},
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...members.map((member) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(member['name']!, style: Theme.of(context).textTheme.bodyMedium),
                  Text(member['role']!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey)),
                ],
              ),
            )),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => context.push('/groups/$groupId/members'),
                  child: const Text('View All'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  void _changeGroupPhoto(BuildContext context) {
    // TODO: Implement file picker and upload logic
  }
}
